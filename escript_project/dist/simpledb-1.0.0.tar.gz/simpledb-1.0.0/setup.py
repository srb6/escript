from setuptools import setup, find_packages

setup(
    name='simpledb',
    version='1.0.0',
    description='A simple database system for storing various types of data in binary format',
    author='Your Name',
    author_email='your@email.com',
    packages=find_packages(),
    python_requires='>=3.6',
)
