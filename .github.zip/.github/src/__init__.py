"""
EScript: A simple scripting language for interacting with HTML and JavaScript in a serverless environment.
"""

__version__ = "0.1.0"
